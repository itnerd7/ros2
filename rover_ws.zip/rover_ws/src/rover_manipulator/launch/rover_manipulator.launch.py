import os
from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch_ros.actions import Node
from moveit_configs_utils import MoveItConfigsBuilder
import xacro

def generate_launch_description():

    # Specify the name of the package and path to xacro file within the package
    pkg_name = 'rover_manipulator'
    file_subpath = 'urdf/rover_manipulator.urdf.xacro'


    # Use xacro to process the file
    xacro_file = os.path.join(get_package_share_directory(pkg_name),file_subpath)
    robot_description_raw = xacro.process_file(xacro_file).toxml()


    # Configure the node
    robot_state_publisher = Node(
        package='robot_state_publisher',
        executable='robot_state_publisher',
        output='screen',
        parameters=[{'robot_description': robot_description_raw,
        'use_sim_time': True}] # add other parameters here if required
    )

    moveit_config = (
        MoveItConfigsBuilder("rover_manipulator")
        .robot_description(file_path="/home/isro/rover_ws/install/rover_manipulator/share/rover_manipulator/urdf/rover_manipulator.urdf.xacro")
        .trajectory_execution(file_path="/home/isro/rover_ws/install/rover_manipulator/share/rover_manipulator/config/controllers.yaml")
        .planning_scene_monitor(
            publish_robot_description=True, publish_robot_description_semantic=True
        )
        .planning_pipelines(pipelines=["ompl"])
        .to_moveit_configs()
    )

    run_move_group_node = Node(
        package="moveit_ros_move_group",
        executable="move_group",
        output="screen",
        parameters=[moveit_config.to_dict()],
    )

    rviz2 = Node( name='rviz2',
                       package='rviz2',
                       executable='rviz2', 
                       arguments=['-d', [os.path.join(get_package_share_directory(pkg_name), 'config', 'config.rviz')]]
    )

    joint_controller = Node(
        package="controller_manager",
        executable="spawner",
        arguments=["joint_trajectory_controller"],
    )

    joint_broadcaster = Node(
        package="controller_manager",
        executable="spawner",
        arguments=["joint_state_broadcaster"],
    )

    return LaunchDescription([
        robot_state_publisher,
        joint_controller,
        joint_broadcaster,
        moveit_config,
        run_move_group_node,
        rviz2
    ])
